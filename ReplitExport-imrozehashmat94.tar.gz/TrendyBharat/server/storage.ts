import {
  users,
  categories,
  products,
  addresses,
  carts,
  orders,
  orderItems,
  wishlist,
  reviews,
  coupons,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type Product,
  type InsertProduct,
  type Address,
  type InsertAddress,
  type Cart,
  type InsertCart,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type Wishlist,
  type InsertWishlist,
  type Review,
  type InsertReview,
  type Coupon,
  type InsertCoupon,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, ilike, sql, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Category operations
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: string): Promise<boolean>;

  // Product operations
  getProducts(params?: {
    categoryId?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    brand?: string;
    sort?: 'price_asc' | 'price_desc' | 'rating' | 'newest';
    limit?: number;
    offset?: number;
  }): Promise<Product[]>;
  getProductById(id: string): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getFeaturedProducts(limit?: number): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  // Address operations
  getUserAddresses(userId: string): Promise<Address[]>;
  createAddress(address: InsertAddress): Promise<Address>;
  updateAddress(id: string, address: Partial<InsertAddress>): Promise<Address | undefined>;
  deleteAddress(id: string): Promise<boolean>;

  // Cart operations
  getCartItems(userId: string): Promise<(Cart & { product: Product })[]>;
  addToCart(cartItem: InsertCart): Promise<Cart>;
  updateCartItem(id: string, quantity: number): Promise<Cart | undefined>;
  removeFromCart(id: string): Promise<boolean>;
  clearCart(userId: string): Promise<boolean>;

  // Order operations
  getOrders(userId: string): Promise<Order[]>;
  getOrderById(id: string): Promise<(Order & { items: (OrderItem & { product: Product })[] }) | undefined>;
  createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order | undefined>;

  // Wishlist operations
  getWishlist(userId: string): Promise<(Wishlist & { product: Product })[]>;
  addToWishlist(wishlistItem: InsertWishlist): Promise<Wishlist>;
  removeFromWishlist(userId: string, productId: string): Promise<boolean>;

  // Review operations
  getProductReviews(productId: string): Promise<(Review & { user: User })[]>;
  createReview(review: InsertReview): Promise<Review>;

  // Coupon operations
  getCouponByCode(code: string): Promise<Coupon | undefined>;
  validateCoupon(code: string, orderAmount: number): Promise<{ valid: boolean; discount: number; error?: string }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.name));
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.slug, slug));
    return category;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  async updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined> {
    const [updated] = await db.update(categories).set(category).where(eq(categories.id, id)).returning();
    return updated;
  }

  async deleteCategory(id: string): Promise<boolean> {
    const result = await db.delete(categories).where(eq(categories.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Product operations
  async getProducts(params: {
    categoryId?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    brand?: string;
    sort?: 'price_asc' | 'price_desc' | 'rating' | 'newest';
    limit?: number;
    offset?: number;
  } = {}): Promise<Product[]> {
    const conditions = [eq(products.isActive, true)];

    if (params.categoryId) {
      conditions.push(eq(products.categoryId, params.categoryId));
    }

    if (params.search) {
      conditions.push(ilike(products.name, `%${params.search}%`));
    }

    if (params.minPrice) {
      conditions.push(sql`${products.price}::decimal >= ${params.minPrice}`);
    }

    if (params.maxPrice) {
      conditions.push(sql`${products.price}::decimal <= ${params.maxPrice}`);
    }

    if (params.brand) {
      conditions.push(eq(products.brand, params.brand));
    }

    // Determine the order column based on sort parameter
    let orderColumn;
    switch (params.sort) {
      case 'price_asc':
        orderColumn = asc(products.price);
        break;
      case 'price_desc':
        orderColumn = desc(products.price);
        break;
      case 'rating':
        orderColumn = desc(products.rating);
        break;
      case 'newest':
        orderColumn = desc(products.createdAt);
        break;
      default:
        orderColumn = desc(products.createdAt);
    }

    // Build query with conditional chaining
    let query = db.select().from(products).where(and(...conditions)).orderBy(orderColumn);

    if (params.limit && params.offset) {
      return await query.limit(params.limit).offset(params.offset);
    } else if (params.limit) {
      return await query.limit(params.limit);
    } else if (params.offset) {
      return await query.offset(params.offset);
    } else {
      return await query;
    }
  }

  async getProductById(id: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.slug, slug));
    return product;
  }

  async getFeaturedProducts(limit: number = 8): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(and(eq(products.isActive, true), eq(products.isFeatured, true)))
      .limit(limit)
      .orderBy(desc(products.rating));
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined> {
    const [updated] = await db.update(products).set({
      ...product,
      updatedAt: new Date(),
    }).where(eq(products.id, id)).returning();
    return updated;
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Address operations
  async getUserAddresses(userId: string): Promise<Address[]> {
    return await db.select().from(addresses).where(eq(addresses.userId, userId)).orderBy(desc(addresses.isDefault));
  }

  async createAddress(address: InsertAddress): Promise<Address> {
    const [newAddress] = await db.insert(addresses).values(address).returning();
    return newAddress;
  }

  async updateAddress(id: string, address: Partial<InsertAddress>): Promise<Address | undefined> {
    const [updated] = await db.update(addresses).set(address).where(eq(addresses.id, id)).returning();
    return updated;
  }

  async deleteAddress(id: string): Promise<boolean> {
    const result = await db.delete(addresses).where(eq(addresses.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  // Cart operations
  async getCartItems(userId: string): Promise<(Cart & { product: Product })[]> {
    const result = await db
      .select()
      .from(carts)
      .innerJoin(products, eq(carts.productId, products.id))
      .where(eq(carts.userId, userId))
      .orderBy(desc(carts.createdAt));
    
    return result.map(row => ({
      ...row.carts,
      product: row.products,
    }));
  }

  async addToCart(cartItem: InsertCart): Promise<Cart> {
    // Check if item already exists in cart
    const [existing] = await db
      .select()
      .from(carts)
      .where(
        and(
          eq(carts.userId, cartItem.userId),
          eq(carts.productId, cartItem.productId),
          cartItem.size ? eq(carts.size, cartItem.size) : sql`${carts.size} IS NULL`,
          cartItem.color ? eq(carts.color, cartItem.color) : sql`${carts.color} IS NULL`
        )
      );

    if (existing) {
      // Update quantity
      const [updated] = await db
        .update(carts)
        .set({
          quantity: (existing.quantity || 0) + (cartItem.quantity || 1),
          updatedAt: new Date(),
        })
        .where(eq(carts.id, existing.id))
        .returning();
      return updated;
    } else {
      // Insert new item
      const [newItem] = await db.insert(carts).values(cartItem).returning();
      return newItem;
    }
  }

  async updateCartItem(id: string, quantity: number): Promise<Cart | undefined> {
    const [updated] = await db
      .update(carts)
      .set({
        quantity,
        updatedAt: new Date(),
      })
      .where(eq(carts.id, id))
      .returning();
    return updated;
  }

  async removeFromCart(id: string): Promise<boolean> {
    const result = await db.delete(carts).where(eq(carts.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async clearCart(userId: string): Promise<boolean> {
    const result = await db.delete(carts).where(eq(carts.userId, userId));
    return (result.rowCount ?? 0) > 0;
  }

  // Order operations
  async getOrders(userId: string): Promise<Order[]> {
    return await db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
  }

  async getOrderById(id: string): Promise<(Order & { items: (OrderItem & { product: Product })[] }) | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    if (!order) return undefined;

    const items = await db
      .select()
      .from(orderItems)
      .innerJoin(products, eq(orderItems.productId, products.id))
      .where(eq(orderItems.orderId, id));

    return {
      ...order,
      items: items.map(item => ({
        ...item.order_items,
        product: item.products,
      })),
    };
  }

  async createOrder(order: InsertOrder, items: InsertOrderItem[]): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    
    const orderItemsWithOrderId = items.map(item => ({
      ...item,
      orderId: newOrder.id,
    }));
    
    await db.insert(orderItems).values(orderItemsWithOrderId);
    
    return newOrder;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order | undefined> {
    const [updated] = await db
      .update(orders)
      .set({
        status,
        updatedAt: new Date(),
      })
      .where(eq(orders.id, id))
      .returning();
    return updated;
  }

  // Wishlist operations
  async getWishlist(userId: string): Promise<(Wishlist & { product: Product })[]> {
    const result = await db
      .select()
      .from(wishlist)
      .innerJoin(products, eq(wishlist.productId, products.id))
      .where(eq(wishlist.userId, userId))
      .orderBy(desc(wishlist.createdAt));
    
    return result.map(row => ({
      ...row.wishlist,
      product: row.products,
    }));
  }

  async addToWishlist(wishlistItem: InsertWishlist): Promise<Wishlist> {
    const [newItem] = await db.insert(wishlist).values(wishlistItem).returning();
    return newItem;
  }

  async removeFromWishlist(userId: string, productId: string): Promise<boolean> {
    const result = await db
      .delete(wishlist)
      .where(and(eq(wishlist.userId, userId), eq(wishlist.productId, productId)));
    return (result.rowCount ?? 0) > 0;
  }

  // Review operations
  async getProductReviews(productId: string): Promise<(Review & { user: User })[]> {
    const result = await db
      .select()
      .from(reviews)
      .innerJoin(users, eq(reviews.userId, users.id))
      .where(eq(reviews.productId, productId))
      .orderBy(desc(reviews.createdAt));
    
    return result.map(row => ({
      ...row.reviews,
      user: row.users,
    }));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    
    // Update product rating
    const avgResult = await db
      .select({
        avg: sql`AVG(${reviews.rating})`.as('avg'),
        count: sql`COUNT(*)`.as('count'),
      })
      .from(reviews)
      .where(eq(reviews.productId, review.productId));

    if (avgResult[0]) {
      await db
        .update(products)
        .set({
          rating: avgResult[0].avg as string,
          reviewCount: parseInt(avgResult[0].count as string),
          updatedAt: new Date(),
        })
        .where(eq(products.id, review.productId));
    }

    return newReview;
  }

  // Coupon operations
  async getCouponByCode(code: string): Promise<Coupon | undefined> {
    const [coupon] = await db.select().from(coupons).where(eq(coupons.code, code));
    return coupon;
  }

  async validateCoupon(code: string, orderAmount: number): Promise<{ valid: boolean; discount: number; error?: string }> {
    const coupon = await this.getCouponByCode(code);
    
    if (!coupon) {
      return { valid: false, discount: 0, error: "Coupon not found" };
    }

    if (!coupon.isActive) {
      return { valid: false, discount: 0, error: "Coupon is not active" };
    }

    if (coupon.validTo && new Date() > coupon.validTo) {
      return { valid: false, discount: 0, error: "Coupon has expired" };
    }

    if (coupon.minOrderAmount && orderAmount < parseFloat(coupon.minOrderAmount)) {
      return { valid: false, discount: 0, error: `Minimum order amount of ₹${coupon.minOrderAmount} required` };
    }

    if (coupon.usageLimit && (coupon.usedCount ?? 0) >= coupon.usageLimit) {
      return { valid: false, discount: 0, error: "Coupon usage limit exceeded" };
    }

    let discount = 0;
    if (coupon.type === 'percentage') {
      discount = (orderAmount * parseFloat(coupon.value)) / 100;
      if (coupon.maxDiscount && discount > parseFloat(coupon.maxDiscount)) {
        discount = parseFloat(coupon.maxDiscount);
      }
    } else {
      discount = parseFloat(coupon.value);
    }

    return { valid: true, discount };
  }
}

export const storage = new DatabaseStorage();
