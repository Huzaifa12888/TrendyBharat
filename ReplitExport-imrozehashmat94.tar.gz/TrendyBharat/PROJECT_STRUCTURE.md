# Trendy Bharat - Project Structure & Setup Guide

## 🏗️ Complete File Structure

```
trendy-bharat/
├── client/
│   ├── index.html
│   └── src/
│       ├── components/
│       │   ├── ui/           # shadcn/ui components
│       │   ├── Cart.tsx      # Shopping cart component
│       │   ├── CategoryGrid.tsx
│       │   ├── Header.tsx    # Navigation header
│       │   ├── HeroSlider.tsx
│       │   ├── Layout.tsx    # Main layout wrapper
│       │   └── ProductCard.tsx
│       ├── hooks/
│       │   ├── use-mobile.tsx
│       │   ├── use-toast.ts
│       │   └── useAuth.ts    # Authentication hook
│       ├── lib/
│       │   ├── authUtils.ts  # Auth utility functions
│       │   ├── queryClient.ts # TanStack Query setup
│       │   └── utils.ts      # General utilities
│       ├── pages/
│       │   ├── Checkout.tsx  # Checkout process
│       │   ├── Home.tsx      # Homepage
│       │   ├── Landing.tsx   # Landing page for logged out users
│       │   ├── not-found.tsx # 404 page
│       │   ├── Orders.tsx    # Order history
│       │   ├── ProductDetail.tsx
│       │   ├── Products.tsx  # Product listing
│       │   └── Profile.tsx   # User profile
│       ├── App.tsx           # Main React component
│       ├── index.css         # Global styles
│       └── main.tsx          # React entry point
├── server/
│   ├── db.ts                 # Database connection setup
│   ├── index.ts              # Express server entry point
│   ├── replitAuth.ts         # Replit authentication setup
│   ├── routes.ts             # API route definitions
│   ├── storage.ts            # Data access layer
│   └── vite.ts               # Vite development setup
├── shared/
│   └── schema.ts             # Database schema & types
├── components.json           # shadcn/ui configuration
├── drizzle.config.ts         # Drizzle ORM configuration
├── package.json              # Dependencies and scripts
├── postcss.config.js         # PostCSS configuration
├── tailwind.config.ts        # Tailwind CSS configuration
├── tsconfig.json             # TypeScript configuration
├── vite.config.ts            # Vite build configuration
├── .gitignore                # Git ignore rules
├── README.md                 # Project documentation
├── LICENSE                   # MIT License
├── CONTRIBUTING.md           # Contribution guidelines
└── replit.md                 # Project architecture docs
```

## 🚀 Quick Setup Commands

```bash
# Install dependencies
npm install

# Setup database (PostgreSQL required)
npm run db:push

# Start development server
npm run dev

# Build for production
npm run build
```

## 🔑 Required Environment Variables

```env
DATABASE_URL=postgresql://username:password@host:port/database
SESSION_SECRET=your-session-secret
REPL_ID=your-repl-id
REPLIT_DOMAINS=your-replit-domain.replit.app
```

## 📦 Key Dependencies

### Frontend
- React 18 + TypeScript
- Wouter (routing)
- TanStack Query (state management)
- shadcn/ui + Radix UI (components)
- Tailwind CSS (styling)
- Vite (build tool)

### Backend
- Node.js + Express
- Drizzle ORM + PostgreSQL
- Replit Auth (OpenID Connect)
- Express Sessions
- Zod (validation)

## 🗄️ Database Tables

- **users** - User accounts and profiles
- **categories** - Product categories (hierarchical)
- **products** - Product catalog with variants
- **carts** - Shopping cart items
- **orders** - Order records and tracking
- **order_items** - Order line items
- **addresses** - User addresses
- **wishlist** - Saved products
- **reviews** - Product reviews
- **coupons** - Discount codes
- **sessions** - User sessions

## 📡 API Endpoints Summary

### Authentication
- `GET /api/auth/user` - Get current user
- `GET /api/login` - Login
- `GET /api/logout` - Logout

### Products
- `GET /api/products` - List products (with filters)
- `GET /api/products/featured` - Featured products
- `GET /api/products/:slug` - Product details
- `POST /api/products` - Create product (admin)

### Shopping
- `GET /api/cart` - Get cart items
- `POST /api/cart` - Add to cart
- `GET /api/wishlist` - Get wishlist
- `POST /api/orders` - Create order

### User Management
- `GET /api/addresses` - User addresses
- `GET /api/orders` - Order history

## 🎨 UI Components

All components use shadcn/ui for consistent design:
- Forms with validation
- Responsive layouts
- Loading states
- Error handling
- Accessibility features

## 🔧 Development Features

- Hot reload with Vite
- TypeScript throughout
- ESLint + Prettier
- Tailwind CSS IntelliSense
- Database migrations with Drizzle
- Session-based authentication

## 📱 Responsive Design

- Mobile-first approach
- Breakpoints: sm (640px), md (768px), lg (1024px), xl (1280px)
- Touch-friendly navigation
- Optimized images

## 🚀 Deployment Ready

- Configured for Replit deployment
- Production build optimization
- Environment variable management
- Session persistence
- HTTPS support