# Trendy Bharat E-commerce Platform

**Modern e-commerce web application for Indian fashion and footwear**

[![Live Demo](https://img.shields.io/badge/demo-live-green)](https://your-replit-url.replit.app)
[![GitHub](https://img.shields.io/badge/GitHub-Huzaifa12888-blue)](https://github.com/Huzaifa12888/Trendybharat)
[![Built with React](https://img.shields.io/badge/React-18-blue)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.6-blue)](https://www.typescriptlang.org/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-Neon-green)](https://neon.tech/)

## 🌟 Overview

Trendy Bharat is a full-stack e-commerce platform designed specifically for the Indian fashion market, offering clothing and footwear for men, women, and kids. Built with modern web technologies, it provides a seamless shopping experience similar to major e-commerce platforms like Flipkart and Amazon.

## ✨ Key Features

### 🛍️ Shopping Experience
- **Product Catalog** - Browse categories (Men's, Women's, Kids' clothing & footwear)
- **Advanced Search** - Filter by price, brand, size, color, and ratings
- **Product Details** - High-quality images, detailed descriptions, reviews
- **Shopping Cart** - Add/remove items, quantity management, persistent cart
- **Wishlist** - Save favorite items for later purchase

### 👤 User Management
- **Secure Authentication** - Replit Auth integration with OpenID Connect
- **User Profiles** - Personal information, order history, address book
- **Address Management** - Multiple shipping/billing addresses
- **Order Tracking** - Real-time order status updates

### 💳 Checkout & Orders
- **Streamlined Checkout** - Guest checkout and registered user flow
- **Multiple Payment Methods** - COD, Cards, UPI, Net Banking
- **Order Management** - Order history, status tracking, invoice generation
- **Discount System** - Coupon codes and promotional offers

### 🔧 Admin Features
- **Product Management** - Add, edit, delete products and categories
- **Inventory Control** - Stock management and alerts
- **Order Processing** - Order fulfillment and status updates
- **User Management** - Customer support and account management

## 🏗️ Technology Stack

### Frontend
- **React 18** with TypeScript for type-safe development
- **Wouter** for lightweight client-side routing
- **TanStack Query** for server state management and caching
- **shadcn/ui** components built on Radix UI primitives
- **Tailwind CSS** for responsive styling
- **Vite** for fast development and optimized builds

### Backend
- **Node.js** with Express.js for RESTful API
- **TypeScript** throughout the stack for consistency
- **Drizzle ORM** for type-safe database operations
- **PostgreSQL** with Neon serverless hosting
- **Express Sessions** with PostgreSQL store

### Authentication & Security
- **Replit Auth** with OpenID Connect (OIDC)
- **JWT tokens** for secure API access
- **Session management** with PostgreSQL storage
- **Input validation** with Zod schemas

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ 
- PostgreSQL database (provided via Replit/Neon)
- Replit account for authentication

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/Huzaifa12888/Trendybharat.git
cd Trendybharat
```

2. **Install dependencies**
```bash
npm install
```

3. **Environment Setup**
The following environment variables are automatically configured in Replit:
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Session encryption key
- `REPL_ID` - Replit application ID
- `REPLIT_DOMAINS` - Allowed domains for authentication

4. **Database Setup**
```bash
npm run db:push
```

5. **Start Development Server**
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

## 📁 Project Structure

```
trendy-bharat/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Route components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions
│   │   └── App.tsx         # Main application component
│   └── index.html          # HTML template
├── server/                 # Backend Express server
│   ├── db.ts              # Database connection setup
│   ├── routes.ts          # API route definitions
│   ├── storage.ts         # Data access layer
│   ├── replitAuth.ts      # Authentication middleware
│   └── index.ts           # Server entry point
├── shared/                 # Shared TypeScript types and schemas
│   └── schema.ts          # Database schema and Zod validation
├── package.json           # Dependencies and scripts
├── tailwind.config.ts     # Tailwind CSS configuration
├── tsconfig.json          # TypeScript configuration
└── vite.config.ts         # Vite build configuration
```

## 🗄️ Database Schema

The application uses a comprehensive PostgreSQL schema with the following main tables:

- **users** - User accounts and profiles
- **categories** - Product categories (hierarchical)
- **products** - Product catalog with variants and pricing
- **carts** - Shopping cart items
- **orders** - Order records and tracking
- **order_items** - Individual order line items
- **addresses** - User shipping/billing addresses
- **wishlist** - Saved products
- **reviews** - Product reviews and ratings
- **coupons** - Discount codes and promotions
- **sessions** - User session storage

## 🔌 API Endpoints

### Authentication
- `GET /api/auth/user` - Get current user
- `GET /api/login` - Initiate login flow
- `GET /api/logout` - User logout

### Products & Categories
- `GET /api/categories` - List all categories
- `GET /api/products` - List products with filtering
- `GET /api/products/featured` - Featured products
- `GET /api/products/:slug` - Product details
- `POST /api/products` - Create product (admin)

### Shopping Cart
- `GET /api/cart` - Get cart items
- `POST /api/cart` - Add item to cart
- `PUT /api/cart/:id` - Update cart item
- `DELETE /api/cart/:id` - Remove cart item

### Orders & Checkout
- `GET /api/orders` - User order history
- `POST /api/orders` - Create new order
- `GET /api/orders/:id` - Order details

### User Management
- `GET /api/addresses` - User addresses
- `POST /api/addresses` - Add new address
- `GET /api/wishlist` - User wishlist
- `POST /api/wishlist` - Add to wishlist

## 🎨 UI/UX Features

- **Responsive Design** - Mobile-first approach with Tailwind CSS
- **Dark Mode Support** - System preference detection
- **Loading States** - Skeleton screens and loading indicators
- **Error Handling** - Graceful error messages and recovery
- **Accessibility** - ARIA labels and keyboard navigation
- **Performance** - Lazy loading and optimized images

## 🔧 Development Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server
npm run check        # TypeScript type checking
npm run db:push      # Push database schema changes
```

## 🚀 Deployment

### Replit Deployment
1. Push your code to GitHub
2. Import repository to Replit
3. Configure environment variables
4. Deploy using Replit's built-in deployment

### Manual Deployment
1. Build the application: `npm run build`
2. Set production environment variables
3. Start the server: `npm start`

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/new-feature`
3. Commit changes: `git commit -am 'Add new feature'`
4. Push to branch: `git push origin feature/new-feature`
5. Submit a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [React](https://reactjs.org/) - Frontend framework
- [Drizzle ORM](https://orm.drizzle.team/) - Database toolkit
- [shadcn/ui](https://ui.shadcn.com/) - UI component library
- [Tailwind CSS](https://tailwindcss.com/) - CSS framework
- [Replit](https://replit.com/) - Development and hosting platform

## 📞 Support

For support and questions:
- Create an issue on GitHub
- Email: support@trendybharat.com
- Documentation: [Wiki](https://github.com/Huzaifa12888/Trendybharat/wiki)

---

**Made with ❤️ for the Indian fashion market**