import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";

const slides = [
  {
    id: 1,
    title: "Trendy Collection",
    subtitle: "Up to 70% Off on Fashion",
    buttonText: "Shop Now",
    bgColor: "from-primary to-blue-600",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400",
  },
  {
    id: 2,
    title: "Step Up Your Game",
    subtitle: "Premium Footwear Collection",
    buttonText: "Explore",
    bgColor: "from-secondary to-orange-600",
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=400",
  },
];

export default function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const previousSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  };

  useEffect(() => {
    const timer = setInterval(nextSlide, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="bg-white mb-6">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="relative overflow-hidden rounded-lg">
          <div 
            className="flex transition-transform duration-500 slider-content"
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          >
            {slides.map((slide) => (
              <div key={slide.id} className="w-full flex-shrink-0">
                <div className={`relative h-64 md:h-80 bg-gradient-to-r ${slide.bgColor} rounded-lg overflow-hidden`}>
                  <img 
                    src={slide.image}
                    alt={slide.title}
                    className="w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute inset-0 flex items-center justify-start pl-12">
                    <div className="text-white">
                      <h2 className="text-4xl font-bold mb-4">{slide.title}</h2>
                      <p className="text-xl mb-6">{slide.subtitle}</p>
                      <Button className="bg-secondary hover:bg-orange-600 px-6 py-3 rounded-lg font-semibold transition-colors">
                        {slide.buttonText}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          {/* Slider Controls */}
          <button 
            onClick={previousSlide}
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-80 hover:bg-opacity-100 rounded-full p-2"
          >
            <i className="fas fa-chevron-left"></i>
          </button>
          <button 
            onClick={nextSlide}
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white bg-opacity-80 hover:bg-opacity-100 rounded-full p-2"
          >
            <i className="fas fa-chevron-right"></i>
          </button>

          {/* Slide indicators */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentSlide ? 'bg-white' : 'bg-white bg-opacity-50'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
