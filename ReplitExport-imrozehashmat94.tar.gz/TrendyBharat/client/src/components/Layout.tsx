import { ReactNode, useState } from "react";
import Header from "./Header";
import Cart from "./Cart";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [isCartOpen, setIsCartOpen] = useState(false);

  return (
    <div className="min-h-screen bg-neutral dark:bg-gray-900">
      <Header onCartToggle={() => setIsCartOpen(!isCartOpen)} />
      <main>{children}</main>
      <Cart isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
      
      {/* Footer */}
      <footer className="bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Trendy Bharat</h3>
              <p className="text-gray-300 mb-4">Your trusted fashion destination for trendy clothes and shoes across India.</p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-300 hover:text-white"><i className="fab fa-facebook-f"></i></a>
                <a href="#" className="text-gray-300 hover:text-white"><i className="fab fa-twitter"></i></a>
                <a href="#" className="text-gray-300 hover:text-white"><i className="fab fa-instagram"></i></a>
                <a href="#" className="text-gray-300 hover:text-white"><i className="fab fa-youtube"></i></a>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-white">About Us</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white">Contact Us</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white">Size Guide</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white">Track Order</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Policies</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-300 hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white">Return & Exchange</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white">Terms & Conditions</a></li>
                <li><a href="#" className="text-gray-300 hover:text-white">Shipping Policy</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Customer Care</h4>
              <div className="space-y-2">
                <p className="text-gray-300"><i className="fas fa-phone mr-2"></i>1800-XXX-XXXX</p>
                <p className="text-gray-300"><i className="fas fa-envelope mr-2"></i>support@trendybharat.com</p>
                <p className="text-gray-300"><i className="fas fa-clock mr-2"></i>24/7 Customer Support</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p className="text-gray-400">© 2024 Trendy Bharat. All rights reserved. Made with ❤️ in India</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
