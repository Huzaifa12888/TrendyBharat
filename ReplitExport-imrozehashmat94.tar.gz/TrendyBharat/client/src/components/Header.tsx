import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";

interface HeaderProps {
  onCartToggle: () => void;
}

export default function Header({ onCartToggle }: HeaderProps) {
  const { isAuthenticated, user } = useAuth();
  const [location, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const { data: cartItems } = useQuery({
    queryKey: ["/api/cart"],
    enabled: isAuthenticated,
  });

  const cartItemCount = cartItems?.reduce((total: number, item: any) => total + item.quantity, 0) || 0;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      {/* Top banner */}
      <div className="bg-primary text-white py-2 px-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-sm">
          <span>Free Delivery on orders above ₹499</span>
          <span>Customer Care: 1800-XXX-XXXX</span>
        </div>
      </div>
      
      {/* Main header */}
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <h1 className="text-2xl font-bold text-primary">Trendy Bharat</h1>
            <span className="text-sm text-gray-500 ml-2">Explore Plus</span>
          </Link>
          
          {/* Search Bar */}
          <div className="flex-1 max-w-2xl mx-8">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Search for products, brands and more"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pr-12 border-gray-300 focus:border-primary"
              />
              <Button
                type="submit"
                size="sm"
                className="absolute right-1 top-1 h-8 w-8 p-0"
                variant="ghost"
              >
                <i className="fas fa-search text-primary"></i>
              </Button>
            </form>
          </div>
          
          {/* Account & Cart */}
          <div className="flex items-center space-x-6">
            {isAuthenticated ? (
              <Link href="/profile" className="flex items-center space-x-1 cursor-pointer hover:text-primary">
                <i className="fas fa-user"></i>
                <span>{user?.firstName || "Account"}</span>
              </Link>
            ) : (
              <a href="/api/login" className="flex items-center space-x-1 cursor-pointer hover:text-primary">
                <i className="fas fa-user"></i>
                <span>Login</span>
              </a>
            )}
            
            {isAuthenticated && (
              <Link href="/orders" className="flex items-center space-x-1 cursor-pointer hover:text-primary">
                <i className="fas fa-heart"></i>
                <span>Wishlist</span>
              </Link>
            )}
            
            <button
              onClick={onCartToggle}
              className="flex items-center space-x-1 cursor-pointer hover:text-primary relative"
            >
              <i className="fas fa-shopping-cart"></i>
              <span>Cart</span>
              {cartItemCount > 0 && (
                <Badge className="absolute -top-2 -right-2 bg-secondary text-white text-xs h-5 w-5 flex items-center justify-center p-0">
                  {cartItemCount}
                </Badge>
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Navigation Categories */}
      <div className="border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <nav className="flex space-x-8 overflow-x-auto py-3">
            <Link href="/products?category=mens-clothing" className="whitespace-nowrap hover:text-primary transition-colors">
              Men's Clothing
            </Link>
            <Link href="/products?category=womens-clothing" className="whitespace-nowrap hover:text-primary transition-colors">
              Women's Clothing
            </Link>
            <Link href="/products?category=kids-clothing" className="whitespace-nowrap hover:text-primary transition-colors">
              Kids Clothing
            </Link>
            <Link href="/products?category=mens-shoes" className="whitespace-nowrap hover:text-primary transition-colors">
              Men's Shoes
            </Link>
            <Link href="/products?category=womens-shoes" className="whitespace-nowrap hover:text-primary transition-colors">
              Women's Shoes
            </Link>
            <Link href="/products?category=kids-shoes" className="whitespace-nowrap hover:text-primary transition-colors">
              Kids Shoes
            </Link>
            <Link href="/products?sale=true" className="whitespace-nowrap hover:text-primary transition-colors">
              Sale
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
