import { Link } from "wouter";

const categories = [
  {
    name: "Men's Clothing",
    slug: "mens-clothing",
    description: "Shirts, T-shirts & More",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
  },
  {
    name: "Women's Clothing",
    slug: "womens-clothing", 
    description: "Dresses, Tops & More",
    image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
  },
  {
    name: "Kids Clothing",
    slug: "kids-clothing",
    description: "Cute & Comfortable",
    image: "https://images.unsplash.com/photo-1503944583220-79d8926ad5e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
  },
  {
    name: "Men's Shoes",
    slug: "mens-shoes",
    description: "Formal & Casual",
    image: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
  },
  {
    name: "Women's Shoes",
    slug: "womens-shoes",
    description: "Heels, Flats & More",
    image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
  },
  {
    name: "Kids Shoes",
    slug: "kids-shoes",
    description: "Fun & Durable",
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200",
  },
];

export default function CategoryGrid() {
  return (
    <section className="bg-white mb-6">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map((category) => (
            <Link
              key={category.slug}
              href={`/products?category=${category.slug}`}
              className="text-center hover:shadow-lg transition-shadow rounded-lg p-4 cursor-pointer"
            >
              <img 
                src={category.image}
                alt={category.name}
                className="w-full h-32 object-cover rounded-lg mb-3"
              />
              <h3 className="font-semibold text-gray-800">{category.name}</h3>
              <p className="text-sm text-gray-600">{category.description}</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
