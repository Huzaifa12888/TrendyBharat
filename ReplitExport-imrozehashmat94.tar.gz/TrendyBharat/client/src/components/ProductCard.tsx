import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";

interface Product {
  id: string;
  name: string;
  slug: string;
  price: string;
  originalPrice?: string;
  discount?: number;
  brand?: string;
  images: string[];
  rating?: string;
  reviewCount?: number;
}

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const addToCartMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/cart", {
        productId: product.id,
        quantity: 1,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Added to Cart",
        description: `${product.name} has been added to your cart.`,
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Please Login",
          description: "You need to login to add items to cart.",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 1000);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to add item to cart. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isAuthenticated) {
      toast({
        title: "Please Login",
        description: "You need to login to add items to cart.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1000);
      return;
    }

    addToCartMutation.mutate();
  };

  const discountPercentage = product.discount || 0;
  const rating = parseFloat(product.rating || "0");

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 overflow-hidden cursor-pointer product-card">
      <Link href={`/products/${product.slug}`}>
        <img 
          src={product.images[0] || "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"}
          alt={product.name}
          className="w-full h-48 object-cover"
        />
      </Link>
      
      <div className="p-4">
        <Link href={`/products/${product.slug}`}>
          <h3 className="font-semibold text-gray-800 mb-2 hover:text-primary transition-colors">
            {product.name}
          </h3>
        </Link>
        
        {product.brand && (
          <p className="text-sm text-gray-600 mb-2">Brand: {product.brand}</p>
        )}
        
        <div className="flex items-center space-x-2 mb-2">
          <span className="text-lg font-bold text-gray-800">₹{parseFloat(product.price).toLocaleString()}</span>
          {product.originalPrice && (
            <>
              <span className="text-sm text-gray-500 line-through">₹{parseFloat(product.originalPrice).toLocaleString()}</span>
              {discountPercentage > 0 && (
                <Badge variant="secondary" className="text-xs text-success bg-green-100">
                  {discountPercentage}% off
                </Badge>
              )}
            </>
          )}
        </div>
        
        {rating > 0 && (
          <div className="flex items-center space-x-1 mb-3">
            <div className="flex text-yellow-400">
              {[1, 2, 3, 4, 5].map((star) => (
                <i 
                  key={star}
                  className={`text-xs ${
                    star <= Math.floor(rating) 
                      ? "fas fa-star" 
                      : star <= rating 
                        ? "fas fa-star-half-alt" 
                        : "far fa-star"
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-gray-600">
              {rating.toFixed(1)} ({product.reviewCount?.toLocaleString() || 0})
            </span>
          </div>
        )}
        
        <Button 
          onClick={handleAddToCart}
          disabled={addToCartMutation.isPending}
          className="w-full bg-secondary hover:bg-orange-600 text-white font-semibold transition-colors"
        >
          {addToCartMutation.isPending ? "Adding..." : "Add to Cart"}
        </Button>
      </div>
    </div>
  );
}
