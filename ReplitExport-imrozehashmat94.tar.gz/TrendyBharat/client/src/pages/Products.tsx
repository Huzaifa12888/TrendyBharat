import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Layout from "@/components/Layout";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";

export default function Products() {
  const [location, navigate] = useLocation();
  const searchParams = new URLSearchParams(location.split('?')[1] || '');
  
  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    minPrice: parseInt(searchParams.get('minPrice') || '0'),
    maxPrice: parseInt(searchParams.get('maxPrice') || '10000'),
    brand: searchParams.get('brand') || '',
    sort: searchParams.get('sort') || 'newest',
  });

  const [priceRange, setPriceRange] = useState([filters.minPrice, filters.maxPrice]);

  const { data: products = [], isLoading, error } = useQuery({
    queryKey: ["/api/products", filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.search) params.append('search', filters.search);
      if (filters.category) params.append('categoryId', filters.category);
      if (filters.minPrice > 0) params.append('minPrice', filters.minPrice.toString());
      if (filters.maxPrice < 10000) params.append('maxPrice', filters.maxPrice.toString());
      if (filters.brand) params.append('brand', filters.brand);
      if (filters.sort) params.append('sort', filters.sort);
      
      const response = await fetch(`/api/products?${params.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
  });

  const updateFilters = (newFilters: Partial<typeof filters>) => {
    const updated = { ...filters, ...newFilters };
    setFilters(updated);
    
    // Update URL
    const params = new URLSearchParams();
    Object.entries(updated).forEach(([key, value]) => {
      if (value && value !== '' && value !== 0) {
        params.append(key, value.toString());
      }
    });
    navigate(`/products?${params.toString()}`);
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      category: '',
      minPrice: 0,
      maxPrice: 10000,
      brand: '',
      sort: 'newest',
    });
    setPriceRange([0, 10000]);
    navigate('/products');
  };

  const handlePriceChange = (value: number[]) => {
    setPriceRange(value);
    updateFilters({ minPrice: value[0], maxPrice: value[1] });
  };

  const brands = [...new Set(products.map((p: any) => p.brand).filter(Boolean))];

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-1/4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Filters</h3>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={clearFilters}
                    className="text-primary hover:text-primary"
                  >
                    Clear All
                  </Button>
                </div>

                {/* Search */}
                <div className="mb-6">
                  <label className="block text-sm font-medium mb-2">Search</label>
                  <Input
                    type="text"
                    placeholder="Search products..."
                    value={filters.search}
                    onChange={(e) => updateFilters({ search: e.target.value })}
                  />
                </div>

                {/* Price Range */}
                <div className="mb-6">
                  <label className="block text-sm font-medium mb-2">
                    Price Range: ₹{priceRange[0]} - ₹{priceRange[1]}
                  </label>
                  <Slider
                    value={priceRange}
                    onValueChange={handlePriceChange}
                    max={10000}
                    min={0}
                    step={100}
                    className="w-full"
                  />
                </div>

                {/* Brand Filter */}
                {brands.length > 0 && (
                  <div className="mb-6">
                    <label className="block text-sm font-medium mb-2">Brand</label>
                    <Select value={filters.brand} onValueChange={(value) => updateFilters({ brand: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select brand" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Brands</SelectItem>
                        {brands.map((brand) => (
                          <SelectItem key={brand} value={brand}>
                            {brand}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Category Quick Links */}
                <div className="mb-6">
                  <label className="block text-sm font-medium mb-2">Categories</label>
                  <div className="space-y-2">
                    {[
                      { name: "Men's Clothing", value: "mens-clothing" },
                      { name: "Women's Clothing", value: "womens-clothing" },
                      { name: "Kids Clothing", value: "kids-clothing" },
                      { name: "Men's Shoes", value: "mens-shoes" },
                      { name: "Women's Shoes", value: "womens-shoes" },
                      { name: "Kids Shoes", value: "kids-shoes" },
                    ].map((category) => (
                      <Button
                        key={category.value}
                        variant={filters.category === category.value ? "default" : "ghost"}
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => updateFilters({ category: category.value })}
                      >
                        {category.name}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Products Grid */}
          <div className="lg:w-3/4">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold text-gray-800 mb-2">
                  {filters.search ? `Search results for "${filters.search}"` : 'All Products'}
                </h1>
                <p className="text-gray-600">
                  {isLoading ? 'Loading...' : `${products.length} products found`}
                </p>
              </div>

              {/* Sort Options */}
              <div className="flex items-center space-x-4 mt-4 sm:mt-0">
                <span className="text-sm text-gray-600">Sort by:</span>
                <Select value={filters.sort} onValueChange={(value) => updateFilters({ sort: value })}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="price_asc">Price: Low to High</SelectItem>
                    <SelectItem value="price_desc">Price: High to Low</SelectItem>
                    <SelectItem value="rating">Customer Rating</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Active Filters */}
            {(filters.search || filters.category || filters.brand || filters.minPrice > 0 || filters.maxPrice < 10000) && (
              <div className="flex flex-wrap gap-2 mb-6">
                {filters.search && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    Search: {filters.search}
                    <button onClick={() => updateFilters({ search: '' })}>
                      <i className="fas fa-times text-xs"></i>
                    </button>
                  </Badge>
                )}
                {filters.category && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    Category: {filters.category}
                    <button onClick={() => updateFilters({ category: '' })}>
                      <i className="fas fa-times text-xs"></i>
                    </button>
                  </Badge>
                )}
                {filters.brand && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    Brand: {filters.brand}
                    <button onClick={() => updateFilters({ brand: '' })}>
                      <i className="fas fa-times text-xs"></i>
                    </button>
                  </Badge>
                )}
                {(filters.minPrice > 0 || filters.maxPrice < 10000) && (
                  <Badge variant="secondary" className="flex items-center gap-1">
                    Price: ₹{filters.minPrice} - ₹{filters.maxPrice}
                    <button onClick={() => updateFilters({ minPrice: 0, maxPrice: 10000 })}>
                      <i className="fas fa-times text-xs"></i>
                    </button>
                  </Badge>
                )}
              </div>
            )}

            {/* Products Grid */}
            {isLoading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-gray-200 h-48 rounded-lg mb-4"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-gray-200 rounded"></div>
                      <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : error ? (
              <div className="text-center py-12">
                <i className="fas fa-exclamation-triangle text-4xl text-gray-400 mb-4"></i>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Error Loading Products</h3>
                <p className="text-gray-600 mb-4">There was an error loading the products. Please try again.</p>
                <Button onClick={() => window.location.reload()}>
                  Retry
                </Button>
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-12">
                <i className="fas fa-search text-4xl text-gray-400 mb-4"></i>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">No Products Found</h3>
                <p className="text-gray-600 mb-4">
                  We couldn't find any products matching your criteria. Try adjusting your filters.
                </p>
                <Button onClick={clearFilters}>
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product: any) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
