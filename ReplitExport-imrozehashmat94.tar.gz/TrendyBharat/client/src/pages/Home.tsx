import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/Layout";
import HeroSlider from "@/components/HeroSlider";
import CategoryGrid from "@/components/CategoryGrid";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";

const newArrivals = [
  { name: "Designer Kurta", slug: "designer-kurta", startingPrice: "₹899", image: "https://images.unsplash.com/photo-1583743089695-4b816a340f82?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { name: "Casual Wear", slug: "casual-wear", startingPrice: "₹599", image: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { name: "Sports Shoes", slug: "sports-shoes", startingPrice: "₹1,999", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { name: "Accessories", slug: "accessories", startingPrice: "₹299", image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { name: "Kids Party Wear", slug: "kids-party-wear", startingPrice: "₹499", image: "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
  { name: "Handbags", slug: "handbags", startingPrice: "₹1,299", image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" },
];

const deals = [
  {
    title: "Fashion Week Sale",
    subtitle: "Up to 80% off on top brands",
    discount: "80% OFF",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
  },
  {
    title: "Footwear Carnival",
    subtitle: "Buy 1 Get 1 Free on shoes",
    discount: "BOGO",
    image: "https://images.unsplash.com/photo-1556906781-9a412961c28c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
  },
  {
    title: "New User Special",
    subtitle: "Extra ₹500 off on first order",
    discount: "₹500 OFF",
    image: "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=200",
  },
];

export default function Home() {
  const { data: featuredProducts = [], isLoading } = useQuery({
    queryKey: ["/api/products/featured"],
  });

  return (
    <Layout>
      <HeroSlider />
      <CategoryGrid />
      
      {/* Featured Products */}
      <section className="bg-white mb-6">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800">Featured Products</h2>
            <Link href="/products">
              <Button variant="ghost" className="text-primary hover:underline">
                View All
              </Button>
            </Link>
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 h-48 rounded-lg mb-4"></div>
                  <div className="space-y-2">
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.slice(0, 4).map((product: any) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Deals Section */}
      <section className="bg-gradient-to-r from-primary to-blue-600 mb-6">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="text-center text-white mb-8">
            <h2 className="text-3xl font-bold mb-2">Today's Best Deals</h2>
            <p className="text-lg">Limited time offers - Don't miss out!</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {deals.map((deal, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow">
                <img 
                  src={deal.image}
                  alt={deal.title}
                  className="w-full h-32 object-cover"
                />
                <CardContent className="p-4">
                  <h3 className="font-bold text-lg text-gray-800 mb-2">{deal.title}</h3>
                  <p className="text-gray-600 mb-3">{deal.subtitle}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-primary">{deal.discount}</span>
                    <Button className="bg-secondary hover:bg-orange-600 text-white">
                      Shop Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="bg-white mb-6">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800">New Arrivals</h2>
            <Link href="/products?sort=newest">
              <Button variant="ghost" className="text-primary hover:underline">
                View All New Items
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {newArrivals.map((item) => (
              <Link key={item.slug} href={`/products?search=${item.name}`}>
                <div className="text-center hover:shadow-lg transition-shadow rounded-lg p-3 cursor-pointer">
                  <img 
                    src={item.image}
                    alt={item.name}
                    className="w-full h-28 object-cover rounded-lg mb-2"
                  />
                  <h4 className="font-medium text-gray-800 text-sm mb-1">{item.name}</h4>
                  <p className="text-xs text-gray-600 mb-1">Starting {item.startingPrice}</p>
                  <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">New</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="bg-white mb-6 border-t border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="flex flex-col items-center">
              <div className="bg-primary bg-opacity-10 p-4 rounded-full mb-3">
                <i className="fas fa-shipping-fast text-2xl text-primary"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-1">Free Shipping</h3>
              <p className="text-sm text-gray-600">On orders above ₹499</p>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="bg-primary bg-opacity-10 p-4 rounded-full mb-3">
                <i className="fas fa-undo text-2xl text-primary"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-1">Easy Returns</h3>
              <p className="text-sm text-gray-600">30-day return policy</p>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="bg-primary bg-opacity-10 p-4 rounded-full mb-3">
                <i className="fas fa-shield-alt text-2xl text-primary"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-1">Secure Payment</h3>
              <p className="text-sm text-gray-600">100% secure transactions</p>
            </div>
            
            <div className="flex flex-col items-center">
              <div className="bg-primary bg-opacity-10 p-4 rounded-full mb-3">
                <i className="fas fa-headset text-2xl text-primary"></i>
              </div>
              <h3 className="font-semibold text-gray-800 mb-1">24/7 Support</h3>
              <p className="text-sm text-gray-600">Always here to help</p>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
