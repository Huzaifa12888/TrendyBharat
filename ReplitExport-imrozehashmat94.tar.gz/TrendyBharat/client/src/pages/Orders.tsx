import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Layout from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Orders() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      toast({
        title: "Please Login",
        description: "You need to login to view your orders.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1000);
    }
  }, [isAuthenticated, toast]);

  const { data: orders = [], isLoading, error } = useQuery({
    queryKey: ["/api/orders"],
    enabled: isAuthenticated,
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  const { data: orderDetails } = useQuery({
    queryKey: ["/api/orders", selectedOrder?.id],
    enabled: !!selectedOrder?.id,
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
      }
    },
  });

  if (!isAuthenticated) {
    return (
      <Layout>
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center py-12">
            <i className="fas fa-user-lock text-4xl text-gray-400 mb-4"></i>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Please Login</h3>
            <p className="text-gray-600">You need to login to view your orders.</p>
          </div>
        </div>
      </Layout>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "confirmed": return "bg-blue-100 text-blue-800";
      case "shipped": return "bg-purple-100 text-purple-800";
      case "delivered": return "bg-green-100 text-green-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending": return "fas fa-clock";
      case "confirmed": return "fas fa-check-circle";
      case "shipped": return "fas fa-truck";
      case "delivered": return "fas fa-home";
      case "cancelled": return "fas fa-times-circle";
      default: return "fas fa-question-circle";
    }
  };

  const getTrackingSteps = (status: string) => {
    const steps = [
      { key: "pending", label: "Order Placed", icon: "fas fa-shopping-cart" },
      { key: "confirmed", label: "Confirmed", icon: "fas fa-check" },
      { key: "shipped", label: "Shipped", icon: "fas fa-truck" },
      { key: "delivered", label: "Delivered", icon: "fas fa-home" },
    ];

    const statusOrder = ["pending", "confirmed", "shipped", "delivered"];
    const currentIndex = statusOrder.indexOf(status);

    return steps.map((step, index) => ({
      ...step,
      completed: index <= currentIndex,
      active: index === currentIndex,
    }));
  };

  const filterOrders = (filterStatus: string) => {
    if (filterStatus === "all") return orders;
    return orders.filter((order: any) => order.status === filterStatus);
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="space-y-6">
            <div className="h-8 bg-gray-200 rounded w-48 animate-pulse"></div>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <div className="h-6 bg-gray-200 rounded w-32"></div>
                        <div className="h-6 bg-gray-200 rounded w-20"></div>
                      </div>
                      <div className="h-4 bg-gray-200 rounded w-24"></div>
                      <div className="h-4 bg-gray-200 rounded w-20"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="text-center py-12">
            <i className="fas fa-exclamation-triangle text-4xl text-gray-400 mb-4"></i>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Error Loading Orders</h3>
            <p className="text-gray-600 mb-4">There was an error loading your orders. Please try again.</p>
            <Button onClick={() => window.location.reload()}>
              Retry
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-800">My Orders</h1>
            <p className="text-gray-600">Track and manage your orders</p>
          </div>
          <Button onClick={() => window.location.href = "/products"}>
            <i className="fas fa-plus mr-2"></i>
            Continue Shopping
          </Button>
        </div>

        {orders.length === 0 ? (
          <div className="text-center py-12">
            <i className="fas fa-shopping-bag text-4xl text-gray-400 mb-4"></i>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">No orders found</h3>
            <p className="text-gray-600 mb-4">You haven't placed any orders yet. Start shopping!</p>
            <Button onClick={() => window.location.href = "/products"}>
              Browse Products
            </Button>
          </div>
        ) : (
          <Tabs defaultValue="all" className="space-y-6">
            <TabsList>
              <TabsTrigger value="all">All Orders ({orders.length})</TabsTrigger>
              <TabsTrigger value="pending">
                Pending ({filterOrders("pending").length})
              </TabsTrigger>
              <TabsTrigger value="shipped">
                Shipped ({filterOrders("shipped").length})
              </TabsTrigger>
              <TabsTrigger value="delivered">
                Delivered ({filterOrders("delivered").length})
              </TabsTrigger>
            </TabsList>

            {["all", "pending", "shipped", "delivered"].map((status) => (
              <TabsContent key={status} value={status}>
                <div className="space-y-4">
                  {filterOrders(status).map((order: any) => (
                    <Card key={order.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                          <div className="space-y-2">
                            <div className="flex items-center space-x-4">
                              <h3 className="font-semibold text-lg">Order #{order.orderNumber}</h3>
                              <Badge className={getStatusColor(order.status)}>
                                <i className={`${getStatusIcon(order.status)} mr-1`}></i>
                                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                              </Badge>
                            </div>
                            
                            <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                              <span>
                                <i className="fas fa-calendar mr-1"></i>
                                Placed on {new Date(order.createdAt).toLocaleDateString()}
                              </span>
                              <span>
                                <i className="fas fa-rupee-sign mr-1"></i>
                                ₹{parseFloat(order.totalAmount).toLocaleString()}
                              </span>
                              <span>
                                <i className="fas fa-credit-card mr-1"></i>
                                {order.paymentMethod.toUpperCase()}
                              </span>
                              {order.paymentStatus && (
                                <span>
                                  <i className={`fas ${order.paymentStatus === "paid" ? "fa-check-circle text-green-600" : "fa-clock text-yellow-600"} mr-1`}></i>
                                  Payment {order.paymentStatus}
                                </span>
                              )}
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedOrder(order)}
                            >
                              <i className="fas fa-eye mr-2"></i>
                              View Details
                            </Button>
                            
                            {order.status === "shipped" && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-primary border-primary hover:bg-primary hover:text-white"
                              >
                                <i className="fas fa-truck mr-2"></i>
                                Track Order
                              </Button>
                            )}
                            
                            {order.status === "delivered" && (
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-orange-600 border-orange-600 hover:bg-orange-600 hover:text-white"
                              >
                                <i className="fas fa-redo mr-2"></i>
                                Reorder
                              </Button>
                            )}
                          </div>
                        </div>

                        {/* Order Tracking Steps */}
                        {order.status !== "cancelled" && (
                          <div className="mt-6 pt-4 border-t">
                            <div className="flex items-center justify-between">
                              {getTrackingSteps(order.status).map((step, index) => (
                                <div key={step.key} className="flex flex-col items-center">
                                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                    step.completed 
                                      ? "bg-primary text-white" 
                                      : step.active 
                                        ? "bg-primary/20 text-primary border-2 border-primary"
                                        : "bg-gray-200 text-gray-400"
                                  }`}>
                                    <i className={`${step.icon} text-sm`}></i>
                                  </div>
                                  <span className={`text-xs mt-1 ${
                                    step.completed || step.active ? "text-primary font-medium" : "text-gray-400"
                                  }`}>
                                    {step.label}
                                  </span>
                                  {index < getTrackingSteps(order.status).length - 1 && (
                                    <div className={`hidden lg:block absolute w-24 h-0.5 ${
                                      step.completed ? "bg-primary" : "bg-gray-200"
                                    }`} style={{ left: "calc(100% + 1rem)" }}></div>
                                  )}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        )}

        {/* Order Details Modal */}
        {selectedOrder && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between">
                <h2 className="text-2xl font-bold">Order Details</h2>
                <button 
                  onClick={() => setSelectedOrder(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <i className="fas fa-times text-xl"></i>
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Order Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Order Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Order Number:</span>
                          <span className="font-medium">{selectedOrder.orderNumber}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Order Date:</span>
                          <span>{new Date(selectedOrder.createdAt).toLocaleDateString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Status:</span>
                          <Badge className={getStatusColor(selectedOrder.status)}>
                            {selectedOrder.status.charAt(0).toUpperCase() + selectedOrder.status.slice(1)}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Payment Method:</span>
                          <span>{selectedOrder.paymentMethod.toUpperCase()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Payment Status:</span>
                          <span className={selectedOrder.paymentStatus === "paid" ? "text-green-600" : "text-yellow-600"}>
                            {selectedOrder.paymentStatus.charAt(0).toUpperCase() + selectedOrder.paymentStatus.slice(1)}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Shipping Address</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {selectedOrder.shippingAddress && (
                        <div className="space-y-1">
                          <p className="font-medium">
                            {selectedOrder.shippingAddress.firstName} {selectedOrder.shippingAddress.lastName}
                          </p>
                          <p>{selectedOrder.shippingAddress.addressLine1}</p>
                          {selectedOrder.shippingAddress.addressLine2 && (
                            <p>{selectedOrder.shippingAddress.addressLine2}</p>
                          )}
                          <p>
                            {selectedOrder.shippingAddress.city}, {selectedOrder.shippingAddress.state} - {selectedOrder.shippingAddress.pincode}
                          </p>
                          <p>Phone: {selectedOrder.shippingAddress.phone}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* Order Items */}
                {orderDetails && orderDetails.items && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Order Items</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {orderDetails.items.map((item: any) => (
                          <div key={item.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                            <img 
                              src={item.product.images?.[0] || "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80"}
                              alt={item.product.name}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <div className="flex-1">
                              <h4 className="font-medium">{item.product.name}</h4>
                              <p className="text-sm text-gray-600">
                                Qty: {item.quantity}
                                {item.size && ` • Size: ${item.size}`}
                                {item.color && ` • Color: ${item.color}`}
                              </p>
                            </div>
                            <div className="text-right">
                              <p className="font-medium">₹{parseFloat(item.price).toLocaleString()}</p>
                              <p className="text-sm text-gray-600">per item</p>
                            </div>
                            <div className="text-right">
                              <p className="font-bold">₹{(parseFloat(item.price) * item.quantity).toLocaleString()}</p>
                              <p className="text-sm text-gray-600">total</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Order Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Order Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Subtotal:</span>
                        <span>₹{(parseFloat(selectedOrder.totalAmount) - parseFloat(selectedOrder.shippingAmount || "0") + parseFloat(selectedOrder.discountAmount || "0")).toLocaleString()}</span>
                      </div>
                      
                      {parseFloat(selectedOrder.shippingAmount || "0") > 0 && (
                        <div className="flex justify-between">
                          <span>Shipping:</span>
                          <span>₹{parseFloat(selectedOrder.shippingAmount).toLocaleString()}</span>
                        </div>
                      )}
                      
                      {parseFloat(selectedOrder.discountAmount || "0") > 0 && (
                        <div className="flex justify-between text-green-600">
                          <span>Discount:</span>
                          <span>-₹{parseFloat(selectedOrder.discountAmount).toLocaleString()}</span>
                        </div>
                      )}
                      
                      <Separator />
                      
                      <div className="flex justify-between font-bold text-lg">
                        <span>Total:</span>
                        <span>₹{parseFloat(selectedOrder.totalAmount).toLocaleString()}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
}
