# Trendy Bharat E-commerce Platform

## Overview

Trendy Bharat is a full-stack e-commerce web application dedicated to selling fashion items (clothing and shoes) in India. The platform provides a modern, responsive shopping experience similar to Flipkart/Amazon, featuring comprehensive product browsing, cart management, checkout processes, and user account functionality. The application supports categories for men's, women's, and kids' clothing and footwear with advanced filtering, search capabilities, and a complete order management system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development practices
- **Routing**: Wouter for lightweight client-side routing
- **UI Library**: shadcn/ui components built on Radix UI primitives for accessible, customizable interface elements
- **Styling**: Tailwind CSS with custom design tokens and CSS variables for consistent theming
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js for RESTful API server
- **Language**: TypeScript throughout the stack for consistency and type safety
- **Database ORM**: Drizzle ORM for type-safe database operations with PostgreSQL
- **Session Management**: Express sessions with PostgreSQL store for user authentication
- **Authentication**: Replit Auth integration using OpenID Connect (OIDC) for secure user management

### Database Design
- **Database**: PostgreSQL with connection pooling via Neon serverless
- **Schema**: Comprehensive e-commerce schema including:
  - Users with admin roles and profile information
  - Hierarchical product categories with slug-based routing
  - Products with variants, images, pricing, and inventory tracking
  - Shopping cart with user-specific item management
  - Order management with detailed item tracking and status updates
  - User addresses for shipping and billing
  - Wishlist functionality for saved items
  - Product reviews and ratings system
  - Coupon and discount management
- **Migrations**: Drizzle Kit for database schema versioning and deployment

### API Architecture
- **Design Pattern**: RESTful API with consistent endpoint structure
- **Authentication Middleware**: Protected routes requiring user authentication
- **Error Handling**: Centralized error handling with appropriate HTTP status codes
- **Validation**: Zod schemas for request/response validation and type inference
- **CRUD Operations**: Complete product catalog, cart management, order processing, and user profile management

### Key Features Implementation
- **Product Management**: Category-based browsing, search with filters, product variants (size, color)
- **Shopping Experience**: Add to cart, wishlist, quantity management, price calculations
- **Checkout Process**: Address selection, delivery options, multiple payment methods, order confirmation
- **User Management**: Profile management, order history, address book, authentication flow
- **Admin Functions**: Product and category management with role-based access control

## External Dependencies

### Database & Infrastructure
- **Neon Database**: Serverless PostgreSQL with connection pooling and automatic scaling
- **WebSocket Support**: Real-time database connections via ws library

### Authentication & Security
- **Replit Auth**: OIDC-based authentication with session management
- **OpenID Client**: Standards-compliant authentication flow implementation
- **Session Storage**: PostgreSQL-backed session store with configurable TTL

### UI & Styling
- **Radix UI**: Comprehensive primitive components for accessibility and customization
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Lucide Icons**: Modern icon library for consistent visual elements
- **Google Fonts**: Inter font family for typography

### Development & Build
- **Vite**: Fast build tool with hot module replacement and optimized bundling
- **TypeScript**: Static type checking and enhanced developer experience
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer for browser compatibility

### Form & Data Management
- **React Hook Form**: Performant form handling with validation
- **TanStack Query**: Server state management with caching and background updates
- **Date-fns**: Date manipulation and formatting utilities
- **Zod**: Schema validation for type-safe data handling

### Additional Utilities
- **Class Variance Authority**: Type-safe CSS class management
- **CLSX**: Conditional className utility for dynamic styling
- **Memoizee**: Function memoization for performance optimization